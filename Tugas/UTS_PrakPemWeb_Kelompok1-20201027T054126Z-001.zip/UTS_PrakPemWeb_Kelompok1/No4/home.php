<?php
$bd = [
    "Lingkaran",
    "Persegi",
    "Segitiga Sama Sisi",
    "Segitiga Siku-siku",
    "Segitiga Sama Kaki",
    "Jajar Genjang",
    "Layang-layang",
];
?>
<html> 
    <title>Bangun Datar</title>
    <link ref=<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <head></head>
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
      <a class="navbar-brand" href="#">UTS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
        </div>
      </div>
    </div>
</nav>
</header>
<body>
<div class="container">
<h1 class="text-center mt-5 font-weight-bold">LUAS DAN KELILING BANGUN DATAR</h1>
<div class="form-group">
    <label for="bangundatar">Pilih Bangun Datar</label>
    <select class="form-control" id="bangundatar">
    <?php foreach ($bd as $elemen): ?>
    <option><?= $elemen ?></option>
    <?php endforeach ?>;
    </select>
</div>
<button type="submit" class="btn btn-success" onClick='top.location="persegi.php"'>Submit</button>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

</body>
</html>