<?php
namespace BangunRuang;

class BangunRuang
{
    private static $bangunruang = [
        "Kubus",
        "Balok",
        "Tabung",
        "Kerucut",
        "Bola"
    ];

    /**
     * @return string[]
     */
    public static function getBangunruang(): array
    {
        return self::$bangunruang;
    }
}
