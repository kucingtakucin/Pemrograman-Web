<?php
require_once "BangunRuang.php";
use BangunRuang\BangunRuang;

class Kubus extends BangunRuang
{
    /**
     * Menghitung keliling kubus
     * @return int
     */
    public static function keliling(): int
    {
        return 12 * (int)$_POST['sisi'];
    }

    /**
     * Menghitung luas kubus
     * @return int
     */
    public static function luas(): int
    {
        return 6 * (int)$_POST['sisi'] ** 2;
    }

    /**
     * Menghitung volume kubus
     * @return int
     */
    public static function volume(): int
    {
        return (int)$_POST['sisi'] ** 3;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kubus</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">UTS</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
                    <a class="nav-link" href="Kubus.php">Kubus</a>
                    <a class="nav-link" href="Balok.php">Balok</a>
                    <a class="nav-link" href="Tabung.php">Tabung</a>
                    <a class="nav-link" href="Kerucut.php">Kerucut</a>
                    <a class="nav-link" href="Bola.php">Bola</a>

                    <!--            <a class="nav-link" href="#">Features</a>-->
                    <!--            <a class="nav-link" href="#">Pricing</a>-->
                    <!--                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>-->
                </div>
            </div>
        </div>
    </nav>
</header>
<main>
    <?php
        $error = false;
        $bukan_angka = false;
        if (isset($_POST['submit'])):
            if (empty(trim($_POST['sisi']))) {
                $error = true;
            } elseif (!is_numeric($_POST['sisi'])) {
                $bukan_angka = true;
            }
        endif;
    ?>
    <div class="container">
        <h1 class="text-center mt-5 font-weight-bold">KUBUS</h1>
        <div class="text-center">
            <img src="img/kubus.png" alt="kubus" width=40%>
        </div>
        <form action="" method="post">
            <div class="form-group">
                <label for="sisi">Sisi</label>
                <input type="text" name="sisi" id="sisi" class="form-control <?php if ($error || $bukan_angka): ?> is-invalid <?php endif ?>">
                <?php if($error): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
                <?php if($bukan_angka): ?>
                    <div class="invalid-feedback">
                        Yang kamu masukkan bukan angka
                    </div>
                <?php endif ?>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-lg btn-primary">Submit</button>
            </div>
        </form>
    </div>
</main>

<!--  Modal -->
<?php if (isset($_POST['submit']) && !$error && !$bukan_angka): ?>
<div class="modal fade" tabindex="-1" id="kubus">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Keliling, Luas Permukaan, dan Volume Kubus</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Keliling: <b><?= number_format(Kubus::keliling()) ?></b></p>
                <p>Luas: <b><?= number_format(Kubus::luas()) ?></b></p>
                <p>Volume: <b><?= number_format(Kubus::volume()) ?></b></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif ?>

<footer>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        if (document.getElementById('kubus')) {
            $('#kubus').modal('show');
        }
    });
</script>
</body>
</html>