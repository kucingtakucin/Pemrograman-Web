<?php
require_once "BangunRuang.php";
use BangunRuang\BangunRuang;

class Tabung extends BangunRuang {
    /**
     * Menghitung luas tabung
     * @return int
     */
    public static function luas(): int
    {
        return 2 * M_PI * (int)$_POST['jari'] * ((int)$_POST['jari'] + (int)$_POST['tinggi']);
    }

    /**
     * Menghitung volume tabung
     * @return int
     */
    public static function volume(): int
    {
        return M_PI * ((int)$_POST['jari'] ** 2) * (int)$_POST['tinggi'];
    }
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tabung</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">UTS</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
                    <a class="nav-link" href="Kubus.php">Kubus</a>
                    <a class="nav-link" href="Balok.php">Balok</a>
                    <a class="nav-link" href="Tabung.php">Tabung</a>
                    <a class="nav-link" href="Kerucut.php">Kerucut</a>
                    <a class="nav-link" href="Bola.php">Bola</a>


                    <!--            <a class="nav-link" href="#">Features</a>-->
                    <!--            <a class="nav-link" href="#">Pricing</a>-->
                    <!--                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>-->
                </div>
            </div>
        </div>
    </nav>
</header>
<main>
    <div class="container">
        <?php
        $error = [
            "jari" => false,
            "tinggi" => false
        ];
        $bukan_angka = [
            "jari" => false,
            "tinggi" => false
        ];
        if (isset($_POST['submit'])) {
            $inputan = array_keys($_POST);
            foreach ($inputan as $item) {
                if (empty(trim($_POST[$item])) && $item !== "submit") {
                    $error[$item] = true;
                    continue;
                }
                if (!is_numeric($_POST[$item]) && $item !== "submit") {
                    $bukan_angka[$item] = true;
                }
            }
        }
        ?>
        <h1 class="text-center mt-5 font-weight-bold">TABUNG</h1>
        <div class="text-center">
            <img src="img/tabung.png" alt="tabung" width=40%>
        </div>
        <form action="" method="post">
            <div class="form-group">
                <label for="jari">Jari-jari</label>
                <input type="text" name="jari" id="jari" class="form-control <?php if ($error['jari'] || $bukan_angka['jari']): ?> is-invalid <?php endif ?>" >
                <?php if($error['jari']): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
                <?php if($bukan_angka['jari']): ?>
                    <div class="invalid-feedback">
                        Yang kamu masukkan bukan angka
                    </div>
                <?php endif ?>
            </div>
            <div class="form-group">
                <label for="tinggi">Tinggi</label>
                <input type="text" name="tinggi" id="tinggi" class="form-control <?php if ($error['tinggi'] || $bukan_angka['tinggi']): ?> is-invalid <?php endif ?>" >
                <?php if($error['tinggi']): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
                <?php if($bukan_angka['tinggi']): ?>
                    <div class="invalid-feedback">
                        Yang kamu masukkan bukan angka
                    </div>
                <?php endif ?>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-lg btn-primary">Submit</button>
            </div>
        </form>
    </div>
</main>

<!--  Modal -->
<?php
$status = false;
foreach ($error as $key => $value):
    if (isset($error[$key]) && $error[$key]) {
        $status = true;
    }
endforeach;
foreach ($bukan_angka as $key => $value):
    if (isset($bukan_angka[$key]) && $bukan_angka[$key]) {
        $status = true;
    }
endforeach;
if (isset($_POST['submit']) && !$status): ?>
    <div class="modal fade" tabindex="-1" id="tabung">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Keliling, Luas Permukaan, dan Volume Tabung</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Luas: <b><?= number_format(Tabung::luas()) ?></b></p>
                    <p>Volume: <b><?= number_format(Tabung::volume()) ?></b></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endif ?>

<footer>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {
        if (document.getElementById('tabung')) {
            $('#tabung').modal('show');
        }
    });
</script>
</body>
</html>