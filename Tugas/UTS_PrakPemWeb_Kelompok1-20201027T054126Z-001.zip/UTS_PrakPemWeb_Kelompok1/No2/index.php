<?php
  // Untuk daftar nilai //
  $daftar = [
    "Adi" => [7,8,6,6,7],
    "Bunga" => [8,9,9,8,7],
    "Candra" => [8,8,9,9,8],
    "Dita" => [6,8,8,6,8],
    "Edgar" => [5,6,5,6,6],
  ];
  $mapel = [
    "Matematika" => [7,8,8,6,5], 
    "Bahasa Indonesia" => [8,9,8,8,6], 
    "Bahasa Inggris" => [6,9,9,8,5], 
    "IPA" => [6,8,9,6,6], 
    "IPS" => [7,7,8,8,6]
  ];
  // Rata-rata tiap siswa //
  $reratasiswa = [];
  $total = 0;
  foreach ($daftar as $key => $value):
    foreach ($value as $nilai):
      $total += $nilai; 
    endforeach;
      $reratasiswa[] = $total / count($value);
      $total = 0;
  endforeach;
  // Rata-rata tiap mapel //
  $reratamapel = [];
  $total2 = 0;
  foreach ($mapel as $key => $value):
    foreach ($value as $nilai):
      $total2 += $nilai; 
    endforeach;
      $reratamapel[] = $total2 / count($value);
      $total2 = 0;
  endforeach;
?>

<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Rata-rata</title>
  <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">UTS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
        </div>
      </div>
    </div>
  </nav>
  <div class="container mt-5 border border-secondary rounded-top">
      <h1 class="text-center">Daftar Nilai Siswa</h1>
      <table class="table table-bordered table-secondary text-center">
        <thead class="text-light bg-secondary">
        <tr>
            <th scope="col">Nama</th>
            <th scope="col">Matematika</th>
            <th scope="col">Bahasa Indonesia</th>
            <th scope="col">Bahasa Inggris</th>
            <th scope="col">IPA</th>
            <th scope="col">IPS</th>
        </tr>
        </thead>
        <tbody class="text-center">
          <?php foreach ($daftar as $key => $elemen):?>
              <tr>
                  <th scope="row"> <?= $key ?></th>
                  <?php foreach ($elemen as $nilai): ?>
                    <td><?=$nilai ?></td>
                  <?php endforeach ?>
              </tr>
          <?php endforeach ?>   
        </tbody>
      </table>

      <br>
      <div class="row">
        <div class="col-md-4">
          <h3 class="text-left">Rata-rata siswa</h3>
          <table class="table table-bordered table-secondary">
            <thead class="text-light bg-secondary">
            <tr>
                <th scope="col">Nama</th>
                <th scope="col">Rata-rata</th>
            </tr>
            </thead>
            <tbody>
              <?php
              $i = 0;
              foreach ($daftar as $key => $elemen):?>
                  <tr>
                      <th scope="row"> <?= $key ?></th>
                      <td><?= $reratasiswa[$i] ?></td>
                  </tr>
              <?php $i++; endforeach ?>   
            </tbody>
          </table>
        </div>
        <div class="col-md-4">
        <h3 class="text-left">Rata-rata Mata Pelajaran</h3>
          <table class="table table-bordered table-secondary">
            <thead class="text-light bg-secondary">
            <tr>
                <th scope="col">Mata Pelajaran</th>
                <th scope="col">Rata-rata</th>
            </tr>
            </thead>
            <tbody>
              <?php
              $i = 0;
              foreach ($mapel as $key => $elemen):?>
                  <tr>
                      <th scope="row"> <?= $key ?></th>
                      <td><?= $reratamapel[$i] ?></td>
                  </tr>
              <?php $i++; endforeach ?>   
            </tbody>
          </table>
        </div>
        <div class="col-md-4">
        <h3 class="text-left">Jurusan</h3>
          <table class="table table-bordered table-secondary">
            <thead class="text-light bg-secondary">
            <tr>
                <th scope="col">Nama</th>
                <th scope="col">Jurusan</th>
            </tr>
            </thead>
            <tbody>
              <?php
              $i = 0;
              foreach ($daftar as $key => $elemen):?>
                  <tr>
                      <th scope="row"> <?= $key ?></th>
                      <td>
                        <?php 
                          if($reratasiswa[$i] >= 6){
                              if ($elemen[3] > $elemen[4]) {
                                echo "Jurusan IPA";
                              } else {
                                echo "Jurusan IPS";
                              }
                            } else {
                              echo "Tidak naik kelas";
                            }
                        ?>
                      </td>
                  </tr>
              <?php $i++; endforeach ?>   
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </body>
</html>
