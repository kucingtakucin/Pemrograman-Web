<?php
require_once "BangunDatar.php";
use BangunDatar\BangunDatar;

class Jajargenjang extends BangunDatar
{
    /**
    *luas jajargenjang
    *@return int
    */
    public static function luas(): int
    {
        return (int)$_POST["alas"]*(int)$_POST["tinggi"];
    }
    /**
    *keliling jajargenjang
    *@return int
    */
    public static function keliling(): int
    {
        return 2*((int)$_POST["alas"]+(int)$_POST["miring"]);
    }
}
?>

<html>
<head>
    <title>Jajar Genjang</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
      <a class="navbar-brand" href="#">UTS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" href="home.php">Home <span class="sr-only">(current)</span></a>
          <a class="nav-link" href="Lingkaran.php">Lingkaran</a>
          <a class="nav-link" href="Persegi.php">Persegi</a>
          <a class="nav-link" href="segitigasamasisi.php">Segitiga Sama Sisi</a>
          <a class="nav-link" href="segitigasikusiku.php">Segitiga Siku-siku</a>
          <a class="nav-link" href="segitigasamakaki.php">Segitiga Sama Kaki</a>
          <a class="nav-link" href="jajargenjang.php">Jajar Genjang</a>
          <a class="nav-link" href="layanglayang.php">Layang-layang</a>
        </div>
      </div>
    </div>
</nav>
</header>

<body>
<div class="container">
<?php 
$error = [
    "alas" => false,
    "tinggi" => false,
    "miring" => false
];
$format = [
    "alas" => false,
    "tinggi" => false,
    "miring" => false
];
if(isset($_POST["submit"])) {
    $inputan = array_keys($_POST);
    foreach ($inputan as $item) {
        if (empty(trim($_POST[$item])) && $item !== "submit") {
            $error[$item] = true;
            continue;
        }
        if (!is_numeric($_POST[$item]) && $item !== "submit"){
            $format[$item] = true;
        }
    }
}
?>
<h1 class="text-center mt-5 font-weight-bold">Jajar Genjang</h1>
<div class="text-center">
    <img src="img/jajargenjang.png" alt="jajargenjang" width=40%>
</div>
<form action="" method="POST">
  <div class="form-group">
    <label for="alas">Alas (cm)</label>
    <input type="text" name="alas" id="alas" class="form-control <?php if ($error['alas'] || $format['alas']): ?>is-invalid<?php endif ?>" >
        <?php if($error['alas']): ?>
            <div class="invalid-feedback">
                Field ini wajib diisi
            </div>
        <?php endif ?>
        <?php if($format['alas']): ?>
            <div class="invalid-feedback">
                Input harus berupa angka
            </div>
        <?php endif ?>
    </div>
    <div class="form-group">
    <label for="tinggi">Tinggi (cm)</label>
        <input type="text" name="tinggi" id="tinggi" class="form-control <?php if ($error['tinggi'] || $format['tinggi']): ?>is-invalid <?php endif ?>"  >
        <?php if($error['tinggi']): ?>
            <div class="invalid-feedback">
                Field ini wajib diisi
            </div>
        <?php endif ?>
        <?php if($format['tinggi']): ?>
            <div class="invalid-feedback">
                Input harus berupa angka
            </div>
        <?php endif ?>
    </div>
    <div class="form-group">
    <label for="atas">Sisi Miring (cm)</label>
    <input type="text" name="miring" id="miring" class="form-control <?php if ($error['miring'] || $format['miring']): ?>is-invalid <?php endif ?>"  >
        <?php if($error['miring']): ?>
            <div class="invalid-feedback">
                Field ini wajib diisi
            </div>
        <?php endif ?>
        <?php if($format['miring']): ?>
            <div class="invalid-feedback">
                Input harus berupa angka
            </div>
        <?php endif ?>
   </div>
  <button type="submit" name="submit" class="btn btn-success">Submit</button>

<?php
$status = false;
foreach ($error as $key => $value):
    if (isset($error[$key]) && $error[$key]){
        $status = true;
    }
endforeach;
foreach ($format as $key => $value):
    if (isset($format[$key]) && $format[$key]){
        $status = true;
    }
endforeach;
if(isset($_POST["submit"])&& $status === false):
?>
    <div class="modal fade" tabindex="-1" id="jajargenjang">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title">Jajar Genjang</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <p>Luas Jajar genjang = <b><?=number_format(JajarGenjang::luas())?> cm<sup>2</sup></b></p>
                <p>Keliling Jajar genjang = <b><?=number_format(JajarGenjang::keliling())?> cm</b></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
<?php endif ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

<script>
    $(document).ready(function() {
        if (document.getElementById('jajargenjang')) {
            $('#jajargenjang').modal('show');
        }
    });
</script>
</body>
</html>