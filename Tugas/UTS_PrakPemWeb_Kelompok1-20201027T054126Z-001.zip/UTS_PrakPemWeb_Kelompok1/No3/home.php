<?php
require_once "BangunDatar.php";
if (isset($_POST['submit'])) {
    header("Location: {$_POST['bangundatar']}.php");
}
?>
<html> 
<head>
    <title>Bangun Datar</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
      <a class="navbar-brand" href="#">UTS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
          <a class="nav-link" href="Lingkaran.php">Lingkaran</a>
          <a class="nav-link" href="Persegi.php">Persegi</a>
          <a class="nav-link" href="segitigasamasisi.php">Segitiga Sama Sisi</a>
          <a class="nav-link" href="segitigasikusiku.php">Segitiga Siku-siku</a>
          <a class="nav-link" href="segitigasamakaki.php">Segitiga Sama Kaki</a>
          <a class="nav-link" href="jajargenjang.php">Jajar Genjang</a>
          <a class="nav-link" href="layanglayang.php">Layang-layang</a>
        </div>
      </div>
    </div>
</nav>
</header>
<main>
    <div class="container">
        <h1 class="text-center mt-5 font-weight-bold">LUAS DAN KELILING BANGUN DATAR</h1>
        <form action="" method="post">
            <div class="form-group">
                <label for="bangundatar">Pilih Bangun Datar: </label>
                <select name="bangundatar" id="bangundatar" class="custom-select form-control">
                    <?php use BangunDatar\BangunDatar;

                    foreach (BangunDatar::getBangundatar() as $elemen): ?>
                        <option value="<?= $elemen ?>"><?= $elemen ?></option>
                    <?php endforeach ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-lg btn-success">Submit</button>
            </div>
        </form>
    </div>
</main>

<footer>
    <h5 class="text-center font-italic">Copyright &copy; 2020. Kelompok 1. All Rights Reserved</h5>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

</body>
</html>