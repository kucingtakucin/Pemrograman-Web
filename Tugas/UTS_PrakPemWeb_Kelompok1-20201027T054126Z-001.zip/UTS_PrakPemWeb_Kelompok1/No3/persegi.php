<?php
require_once "BangunDatar.php";
use BangunDatar\BangunDatar;

class Persegi extends BangunDatar
{
    /**
    *luas persegi
    *@return int
    */
    public static function luas(): int
    {
        return (int)$_POST["sisi"]*(int)$_POST["sisi"];
    }
    /**
    *keliling persegi
    *@return int
    */
    public static function keliling(): int
    {
        return 4*(int)$_POST["sisi"];
    }
}
?>

<html>
<head>
    <title>Persegi</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
      <a class="navbar-brand" href="#">UTS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active" href="home.php">Home <span class="sr-only">(current)</span></a>
          <a class="nav-link" href="Lingkaran.php">Lingkaran</a>
          <a class="nav-link" href="Persegi.php">Persegi</a>
          <a class="nav-link" href="segitigasamasisi.php">Segitiga Sama Sisi</a>
          <a class="nav-link" href="segitigasikusiku.php">Segitiga Siku-siku</a>
          <a class="nav-link" href="segitigasamakaki.php">Segitiga Sama Kaki</a>
          <a class="nav-link" href="jajargenjang.php">Jajar Genjang</a>
          <a class="nav-link" href="layanglayang.php">Layang-layang</a>
        </div>
      </div>
    </div>
</nav>
</header>

<body>
<div class="container">
<?php 
    $error = false;
    $format = false;
    if (isset($_POST["submit"])):
        if (empty(trim($_POST['sisi']))) {
            $error = true;
        } elseif (!is_numeric($_POST['sisi'])) {
            $format = true;
        }
    endif;
?>
<h1 class="text-center mt-5 font-weight-bold">Persegi</h1>
<div class="text-center">
    <img src="img/persegi.png" alt="persegi" width=40%>
</div>
<form action="" method="POST">
    <div class="form-group">
        <label for="sisi">Sisi (cm)</label>
        <input type="text" name="sisi" class="form-control <?php if ($error || $format): ?> is-invalid <?php endif ?>" id="sisi">
        <?php if($error): ?>
            <div class="invalid-feedback">
                Field ini wajib diisi
            </div>
        <?php endif ?>
        <?php if($format): ?>
            <div class="invalid-feedback">
                Input harus berupa angka
            </div>
        <?php endif ?>
    </div>
    <div class="form-group">
        <button type="submit" name="submit" class="btn btn-success">Submit</button>
    </div>
</form>
</div>
<?php
    if (isset($_POST["submit"]) && !$error && !$format):
?>
        <div class="modal fade" tabindex="-1" id="persegi">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title">Persegi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <p>Luas Persegi = <b><?= number_format(Persegi::luas()) ?> cm<sup>2</sup></b> </p>
                    <p>Keliling Persegi =  <b><?= number_format(Persegi::keliling())?> cm</p>

                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    <?php endif ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

<script>
    $(document).ready(function() {
        if (document.getElementById('persegi')) {
            $('#persegi').modal('show');
        }
    });
</script>
</body>
</html>