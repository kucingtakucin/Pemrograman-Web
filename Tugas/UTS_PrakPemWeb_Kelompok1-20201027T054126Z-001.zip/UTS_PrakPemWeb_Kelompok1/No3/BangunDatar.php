<?php
namespace BangunDatar;

class BangunDatar
{
    private static $bangundatar = [
    "Lingkaran",
    "Persegi",
    "SegitigaSamaSisi",
    "SegitigaSikuSiku",
    "SegitigaSamaKaki",
    "Jajargenjang",
    "LayangLayang"
    ];

    /**
     * @return string[]
     */
    public static function getBangundatar(): array
    {
        return self::$bangundatar;
    }
}