<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Perhitungan IPK</title>
    <link rel="stylesheet" href="bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">UTS</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
                </div>
            </div>
        </div>
    </nav>
</header>
<main>
    <div class="container">
        <?php
        // Untuk validasi error kosong, dan bukan angka
        $error_kosong = [
            "nama" => false,
            "nim" => false,
            "prodi" => false,
            "matkul1" => false,
            "matkul2" => false,
            "matkul3" => false,
            "matkul4" => false,
            "matkul5" => false,
            "nilai1" => false,
            "nilai2" => false,
            "nilai3" => false,
            "nilai4" => false,
            "nilai5" => false,
        ];
        if (isset($_POST['submit'])) {
            $inputan = array_keys($_POST);
            foreach ($inputan as $name) { // nama, nim, prodi, ...
                if (empty(trim($_POST[$name])) && $name !== "submit") {  // validasi kosong, submit tidak kita cek
                    $error_kosong[$name] = true;
                }
//                if (!is_numeric($_POST[$item]) && $item !== "submit") { // validasi string, submit tidak kita cek
//                    $bukan_angka[$item] = true;
//                }
            }
        }
        ?>
        <h1 class="text-center mt-5 font-weight-bold">INPUT NILAI MAHASISWA</h1>
        <form action=""  method="post">
            <div class="form-group">
                <label for="nama">Nama</label>
                <input name="nama" type="text" id="nama" class="form-control <?php if ($error_kosong["nama"]): ?> is-invalid <?php endif ?>">
                <?php if($error_kosong["nama"]): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
            </div>
            <div class="form-group">
                <label for="nim">NIM</label>
                <input name="nim" type="text" id="nim" class="form-control <?php if ($error_kosong["nim"]): ?> is-invalid <?php endif ?>">
                <?php if($error_kosong["nim"]): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
            </div>
            <div class="form-group">
                <label for="prodi">Program Studi</label>
                <select name="prodi" id="prodi" class="form-control <?php if ($error_kosong["prodi"]): ?> is-invalid <?php endif ?> custom-select">
                    <option disabled selected>Pilih salah satu</option>
                    <option value="Teknik Elektro">Teknik Elekto</option>
                    <option value="Teknik Informatika">Teknik Informatika</option>
                    <option value="Teknik Mesin">Teknik Mesin</option>
                    <option value="Teknik Fisika">Teknik Fisika</option>
                    <option value="Teknik Kimia">Teknik Kimia</option>
                </select>
                <?php if($error_kosong["prodi"]): ?>
                    <div class="invalid-feedback">
                        Field ini wajib di isi
                    </div>
                <?php endif ?>
            </div>
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <div class="form-group">
                    <label for="matkul<?= $i ?>">Mata Kuliah <?= $i ?></label>
                    <input type="text" name="matkul<?= $i ?>" id="matkul<?= $i ?>" class="form-control <?php if ($error_kosong["matkul$i"]): ?> is-invalid <?php endif ?>">
                    <?php if($error_kosong["matkul$i"]): ?>
                        <div class="invalid-feedback">
                            Field ini wajib di isi
                        </div>
                    <?php endif ?>
                </div>
            <?php endfor ?>
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <div class="form-group">
                    <label for="nilai<?= $i ?>">Nilai <?= $i ?></label>
                    <input type="text" maxlength="1" name="nilai<?= $i ?>" id="nilai" class="form-control <?php if ($error_kosong["nilai$i"]): ?> is-invalid <?php endif ?>">
                    <?php if($error_kosong["nilai$i"]): ?>
                        <div class="invalid-feedback">
                            Field ini wajib di isi
                        </div>
                    <?php endif ?>
                </div>
            <?php endfor ?>
            <div class="form-group">
                <button type="submit" name="submit" class="btn btn-lg btn-primary">Submit</button>
            </div>
        </form>
    </div>

    <!--  Modal -->
    <?php
    $status_error = false;
    foreach ($error_kosong as $key => $value):
        if (isset($error_kosong[$key]) && $error_kosong[$key]) {
            $status_error = true;
        }
    endforeach;
    if (isset($_POST['submit']) && !$status_error):
        $angka = [];    // nilai angka per matkul  [3,4,3,4]
        $bobotnilai = [];   // Bobot nilai per matkul  [12,9,12,9,12]
        $ipk = 0;
        $predikat = "";
        ?>
        <div class="modal fade" tabindex="-1" id="modal_nilai">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Hasil Nilai</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <caption><?= $_POST['nama'] ?> | <?= $_POST['nim'] ?> | <?= $_POST['prodi']?></caption>
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Mata Kuliah</th>
                                <th scope="col">Nilai</th>
                                <th scope="col">Angka</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <tr>
                                    <th scope="row"><?= $i ?></th>
                                    <td><?= $_POST["matkul$i"] ?></td>
                                    <td><?= $_POST["nilai$i"] ?></td>
                                    <td><?php
                                        if ($_POST["nilai$i"] === 'A') {
                                            $angka[] = 4;
                                            $predikat = "Dengan pujian tertinggi";
                                        } elseif ($_POST["nilai$i"] === 'B') {
                                            $angka[] = 3;
                                            $predikat = "Dengan pujian";
                                        } elseif ($_POST["nilai$i"] === 'C') {
                                            $angka[] = 2;
                                            $predikat = "Sangat memuaskan";
                                        } elseif ($_POST["nilai$i"] === 'D') {
                                            $angka[] = 1;
                                            $predikat = "Memuaskan";
                                        } elseif ($_POST["nilai$i"] === 'E') {
                                            $angka[] = 0;
                                            $predikat = "Cukup";
                                        }
                                        $bobotnilai[] = 3 * $angka[$i - 1];
                                        echo $angka[$i - 1] ?></td>
                                </tr>
                            <?php endfor;
                            $ipk = array_sum($bobotnilai) / 15;  // 15 sks ?>
                            </tbody>
                            <tfoot class="bg-secondary text-light">
                                <tr>
                                    <td colspan="3"><b>IPK</b></td>
                                    <td><?= $ipk ?></td>
                                </tr>
                                <tr>
                                    <td colspan="4">Predikat: <b><?= $predikat ?></b></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            if (document.getElementById('modal_nilai')) {
                $('#modal_nilai').modal('show');
            }
        });
    </script>
</main>
</body>
</html>