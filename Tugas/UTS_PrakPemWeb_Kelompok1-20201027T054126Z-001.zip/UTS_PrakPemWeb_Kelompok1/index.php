<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="No1/bootstrap-4.5.3-dist/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
                <a class="navbar-brand" href="#">UTS</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
                        <a class="nav-link active" href="No1">No 1</a>
                        <a class="nav-link active" href="No2">No 2 </a>
                        <a class="nav-link active" href="No3">No 3 </a>
                        <a class="nav-link active" href="No4">No 4 </a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-md-4 offset-4">
                    <div class="card bg-dark shadow-lg rounded-pill mt-5 mb-5 text-light">
                        <div class="card-body d-flex flex-column align-items-center justify-content-center">
                            <h2 class="card-title font-weight-bold">Kelompok 1</h2>
                            <p class="card-text m-0">Adam Arthur Faizal</p>
                            <p class="card-text m-0">Alwi Zein Harahap</p>
                            <p class="card-text m-0">Anggita Sari Wulandari</p>
                            <p class="card-text m-0">Atiqoh Nur Fadhilah</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <h3 class="font-italic text-center">Copyright &copy; 2020. Kelompok 1. All Rights Reserved.</h3>
    </footer>
</body>
</html>