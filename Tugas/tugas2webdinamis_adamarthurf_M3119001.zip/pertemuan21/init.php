<?php
session_start();
require_once 'model.php';
require_once 'controller.php';
session();